﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum NodeResult
{ 
    SUCCESS,FAILURE,RUNNING,STACKED,UNKNOWN
}
